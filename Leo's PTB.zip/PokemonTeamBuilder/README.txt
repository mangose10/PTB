Hello youtube, it's ya boi Leo here with the new updates.
This isn't fully complete, for example it only reads removes temporarily if you restart the pokemon will come back..
The way to manually fix this is by saving the team as "Team" after every time that you remove, or atleast before you exit.
Side note, don't save any team as change


Send heat Tickes here: https://goo.gl/forms/qCLb2jFfLWgbyvHj2
